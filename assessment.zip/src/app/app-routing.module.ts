import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { Registration2Component } from './registration2/registration2.component';
import { SummaryComponent } from './summary/summary.component';

const routes: Routes = [
  {path:'',pathMatch: 'prefix',redirectTo:'Registration'},
  {path:'Registration', component:RegistrationComponent},
  {path:'Registration2',component:Registration2Component},
  {path:'Summary',component:SummaryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
