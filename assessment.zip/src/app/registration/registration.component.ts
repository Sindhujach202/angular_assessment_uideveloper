import { Component, OnInit,Input } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { RegisterformService } from '../registerform.service';

import { IRegistration } from '../registrationclass';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registration: IRegistration = new IRegistration();
  constructor(private route: ActivatedRoute, private router: Router ,private service: RegisterformService) { }
  
  ngOnInit(){
   const details = this.service.getformdetails(); 
   this.registration = details;  
  };
 
  
  
  onSubmit(){       
       this.service.submitform(this.registration);
       this.router.navigateByUrl('Registration2');
       
  }
  

}
