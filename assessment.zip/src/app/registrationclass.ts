export class IRegistration {
    fname: any;
    lname: any;
    email: any;
    mob: any;
    address: any;
    instname: any;
    course: any;
    passyear: any;
    cgpa: any;
    cousers: any;
}