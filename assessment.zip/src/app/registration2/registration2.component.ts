import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { RegisterformService } from '../registerform.service';
import { IRegistration } from '../registrationclass';

@Component({
  selector: 'app-registration2',
  templateUrl: './registration2.component.html',
  styleUrls: ['./registration2.component.css']
})
export class Registration2Component implements OnInit {

  registration: IRegistration = new IRegistration();
  

  constructor(private route: ActivatedRoute, private router: Router ,private service: RegisterformService) { }

  formdetails:any = {};
  courses : any;

  ngOnInit(): void {
    this.formdetails = this.service.getformdetails();
    this.registration = this.formdetails; 
 
    this.registration.course = this.registration.course || '';
    this.courses = this.service.getcoursedetails();
  }

  Previous(){
    this.router.navigateByUrl('Registration');
  }
  onSubmit(){
    this.registration = {...this.formdetails, ...this.registration};
    this.service.submitform(this.registration);
    this.router.navigateByUrl('Summary');
  }
}
