import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { RegisterformService } from '../registerform.service';

import { IRegistration } from '../registrationclass';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  reg : IRegistration = new IRegistration();

  constructor(private route: ActivatedRoute, private router: Router ,private service: RegisterformService) { }

  ngOnInit(): void {
    this.reg = this.service.getformdetails();
  }

  Previous(){
    this.router.navigateByUrl('Registration2');
  }
  onSubmit(){
    console.log(this.reg);
  }

}
