import { formatCurrency } from '@angular/common';
import { Injectable } from '@angular/core';
import { ValidatorFn, AbstractControl, FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class RegisterformService {

  constructor() { }

  fordetails: any = {};
  courses:any = [];

  submitform(fordetails: any){
    this.fordetails = fordetails;
  }

  getformdetails(){
    return this.fordetails;
  }

  getcoursedetails(){
    this.courses = ['UG','PG'];
    return this.courses;
  }
}
